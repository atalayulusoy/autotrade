import { supabase } from '../lib/supabase';
import { apiUrl } from './apiBase';

const safeJson = async (res) => {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
};

const backendFetch = async (path, opts = {}) => {
  const url = apiUrl(path);
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(opts.headers || {})
    },
    ...opts
  });
  return res;
};

const defaultRooms = () => ([
  {
    id: 'global-room',
    roomName: 'Genel Tartisma',
    roomType: 'public',
    tradingPair: 'ALL',
    description: 'Genel sohbet odasi',
    activeUsersCount: 0,
    totalMessagesCount: 0,
    createdBy: null,
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
]);

export const chatService = {
  async getChatRooms() {
    // Prefer backend polling chat API to avoid Supabase RLS/policy recursion errors.
    try {
      const res = await backendFetch('/api/chat/rooms');
      if (res.ok) {
        const data = await safeJson(res);
        const rooms = Array.isArray(data) ? data : (data.rooms || []);
        if (rooms.length) {
          return rooms.map((r) => ({
            id: r.id || r.room_id || r.roomId,
            roomName: r.room_name || r.roomName || 'Oda',
            roomType: r.room_type || r.roomType || 'public',
            tradingPair: r.trading_pair || r.tradingPair || 'ALL',
            description: r.description || '',
            activeUsersCount: r.active_users_count || r.activeUsersCount || 0,
            totalMessagesCount: r.total_messages_count || r.totalMessagesCount || 0,
            createdBy: r.created_by || r.createdBy || null,
            isActive: r.is_active ?? r.isActive ?? true,
            createdAt: r.created_at || r.createdAt || new Date().toISOString(),
            updatedAt: r.updated_at || r.updatedAt || new Date().toISOString()
          }));
        }
      }
    } catch (_) {
      // ignore
    }

    // Fallback: do NOT call Supabase here (it can throw policy recursion). Return defaults.
    return defaultRooms();
  },

  async getRoomMessages(roomId, limit = 50) {
    // Prefer backend
    try {
      const qs = new URLSearchParams({ room_id: String(roomId || ''), limit: String(limit) });
      const res = await backendFetch(`/api/chat/messages?${qs.toString()}`, { method: 'GET' });
      if (res.ok) {
        const payload = await safeJson(res);
        const rows = Array.isArray(payload) ? payload : (payload.messages || []);
        return rows.map((m) => ({
          id: m.id,
          roomId: m.room_id || m.roomId || roomId,
          userId: m.user_id || m.userId || null,
          messageType: m.message_type || m.messageType || 'text',
          content: m.content || m.message || '',
          metadata: m.metadata || null,
          isEdited: !!m.is_edited,
          editedAt: m.edited_at || null,
          isDeleted: !!m.is_deleted,
          deletedAt: m.deleted_at || null,
          createdAt: m.created_at || m.createdAt || new Date().toISOString(),
          userProfile: m.user_profile || m.userProfile || null
        }));
      }
    } catch (_) {
      // ignore
    }

    // Fallback: use local cache (no Supabase to avoid policy recursion)
    try {
      const key = `au_chat_cache_${String(roomId || 'general')}`;
      const raw = localStorage.getItem(key);
      const rows = raw ? JSON.parse(raw) : [];
      return (rows || []).slice(-limit);
    } catch (_) {
      return [];
    }
  },

  async sendMessage(roomId, content, messageType = 'text', metadata = null) {
    // Prefer backend
    try {
      const res = await backendFetch('/api/chat', {
        method: 'POST',
        body: JSON.stringify({
          room_id: roomId,
          roomId,
          message: content,
          content,
          message_type: messageType,
          messageType,
          metadata
        })
      });
      if (res.ok) {
        const data = await safeJson(res);
        return {
          id: data?.id || data?.message_id || String(Date.now()),
          roomId: data?.room_id || roomId,
          userId: data?.user_id || null,
          messageType: data?.message_type || messageType,
          content: data?.content || content,
          metadata: data?.metadata || metadata,
          createdAt: data?.created_at || new Date().toISOString()
        };
      }
    } catch (_) {
      // ignore
    }

    // Fallback: store locally so UI can still send messages without Supabase.
    const msg = {
      id: String(Date.now()),
      roomId: roomId,
      userId: null,
      messageType,
      content,
      metadata,
      createdAt: new Date().toISOString()
    };
    try {
      const key = `au_chat_cache_${String(roomId || 'general')}`;
      const raw = localStorage.getItem(key);
      const rows = raw ? JSON.parse(raw) : [];
      rows.push(msg);
      localStorage.setItem(key, JSON.stringify(rows.slice(-200)));
    } catch (_) {
      // ignore
    }
    return msg;
  },

  // Supabase room memberships are currently erroring due to RLS recursion.
  // We no-op these for now so the UI stays usable.
  async joinRoom() { return { ok: true }; },
  async leaveRoom() { return { ok: true }; },
  async getRoomMembers() { return []; },

  subscribeToMessages() {
    return () => {};
  },

  subscribeToRoomUpdates() {
    return () => {};
  }
};
