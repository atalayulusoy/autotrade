import React, { useMemo, useState } from 'react';
import { TrendingUp } from 'lucide-react';
import { apiUrl } from '../../../services/apiBase';

const pickPrice = (payload, symbol) => {
  if (!payload) return 0;
  const prices = payload?.prices || payload;
  const row = prices?.[symbol];
  const raw = row && typeof row === 'object' ? (row.price ?? row.last ?? row.close) : row;
  const n = Number(raw);
  return Number.isFinite(n) ? n : 0;
};

const ManualTradingPanel = (props) => {
  // Backward compatible props
  const selectedExchange = props.selectedExchange ?? props.manualExchange ?? 'OKX';
  const selectedCoin = props.selectedCoin ?? props.manualCoin ?? 'BTC/USDT';
  const testMode = props.testMode ?? 'TEST';
  const balance = props.balance ?? 0;
  const onExecute = props.onExecute;
  const onActiveCoinUpsert = props.onActiveCoinUpsert;

  const [side, setSide] = useState(props.side ?? (props.tradeType || 'BUY'));
  const [coin, setCoin] = useState(selectedCoin);
  const [amount, setAmount] = useState(String(props.amount ?? props.manualUsdt ?? '20'));
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  const quickAmounts = [10, 20, 50, 100, 500];

  const coins = useMemo(() => {
    const list = props.coins || [];
    const out = list.map((c) => (typeof c === 'string' ? c : c?.symbol)).filter(Boolean);
    return out.length ? out : ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'XRP/USDT'];
  }, [props.coins]);

  const submit = async () => {
    setMsg('');
    const symbol = String(coin || '').trim();
    const amountUsdt = Number(String(amount || '').replace(',', '.'));
    if (!symbol || !symbol.includes('/')) {
      setMsg('Coin formatı hatalı');
      return;
    }
    if (!amountUsdt || amountUsdt <= 0) {
      setMsg('USDT miktarı hatalı');
      return;
    }
    if (testMode === 'TEST' && side === 'BUY' && amountUsdt > Number(balance || 0)) {
      setMsg('Yetersiz bakiye');
      return;
    }

    setLoading(true);
    try {
      // Demo modunda işlemler UI üzerinden simüle edilir
      const tr = await fetch(apiUrl(`/api/public/ticker?symbols=${encodeURIComponent(symbol)}`));
      const td = await tr.json().catch(() => ({}));
      const price = pickPrice(td, symbol);
      if (!price) {
        setMsg('Fiyat alınamadı');
        return;
      }

      if (side === 'BUY') {
        onExecute?.({ side: 'BUY', symbol, amountUsdt, price, exchange: selectedExchange });
        onActiveCoinUpsert?.({
          symbol,
          amount_usdt: amountUsdt,
          entry_price: price,
          qty: amountUsdt / price,
          ts: Date.now(),
          source: 'MANUAL',
        });
        setMsg('BUY işlendi');
        return;
      }

      // SELL
      onExecute?.({ side: 'SELL', symbol, amountUsdt, price, exchange: selectedExchange });
      setMsg('SELL işlendi');
    } catch {
      setMsg('İşlem hatası');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <TrendingUp size={18} className="text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Manuel İşlemler</h3>
      </div>

      <div className="bg-background/50 rounded-lg p-3 border border-border">
        <div className="flex items-center gap-2 mb-3">
          <button
            onClick={() => setSide('BUY')}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold border ${
              side === 'BUY'
                ? 'bg-success text-success-foreground border-success'
                : 'bg-transparent text-muted-foreground border-border'
            }`}
          >
            AL (BUY)
          </button>
          <button
            onClick={() => setSide('SELL')}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold border ${
              side === 'SELL'
                ? 'bg-danger text-danger-foreground border-danger'
                : 'bg-transparent text-muted-foreground border-border'
            }`}
          >
            SAT (SELL)
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="block text-xs text-muted-foreground mb-1">Coin Seçimi</label>
            <select
              value={coin}
              onChange={(e) => setCoin(e.target.value)}
              className="w-full bg-background border border-border rounded-lg px-3 py-2 text-xs text-foreground"
            >
              {coins.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs text-muted-foreground mb-1">Miktar (USDT)</label>
            <input
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-background border border-border rounded-lg px-3 py-2 text-xs text-foreground"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {quickAmounts.map((v) => (
                <button
                  key={v}
                  onClick={() => setAmount(String(v))}
                  className="px-2 py-1 rounded-md border border-border text-xs text-muted-foreground hover:text-foreground"
                >
                  {v} USDT
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Mevcut Bakiye</span>
            <span className="text-foreground font-semibold">{Number(balance || 0).toFixed(2)} USDT</span>
          </div>

          {msg ? <div className="text-xs text-muted-foreground">{msg}</div> : null}

          <button
            onClick={submit}
            disabled={loading}
            className="w-full py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-50"
          >
            {loading ? 'İşleniyor' : `${side === 'BUY' ? 'AL' : 'SAT'} - ${String(coin || 'BTC/USDT')}`}
          </button>
        </div>
      </div>

      <div className="text-xs text-muted-foreground">
        Mod: {testMode === 'TEST' ? 'Demo' : 'Gerçek'}
      </div>
    </div>
  );
};

export default ManualTradingPanel;
