import React from 'react';
import CandlestickChart from '../../trading-dashboard/components/CandlestickChart';

const MarketOverviewChart = ({ selectedCoin }) => {
  return (
    <div className="space-y-6">
      <div className="p-6 rounded-lg bg-card border border-border">
        <CandlestickChart selectedCoin={selectedCoin} />
      </div>
    </div>
  );
};

export default MarketOverviewChart;